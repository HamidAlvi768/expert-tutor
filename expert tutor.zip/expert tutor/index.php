<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment Connect - Connect Individuals to Assign</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/login-modal.css">
</head>
<body>
    <div class="hero-wrapper">
        <!-- Header Section -->
        <?php include 'includes/header.php'; ?>

        <!-- Hero Section -->
        <section class="hero-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7">
                        <h1 class="hero-title">We<span>CONNECT</span> individuals to Assign</h1>
                        <p class="hero-subtitle">Find top talent or open assignments with tools that keep you in control.</p>
                        <div class="search-box">
                            <div class="search-input-wrapper">
                                <input type="text" class="form-control" placeholder="Search For New Service">
                            </div>
                            <button type="button" class="btn btn-primary register-btn" data-bs-toggle="modal" data-bs-target="#signupModal">Register Here!</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Stats Section -->
    <section class="stats-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="stat-item">
                        <h3>67.1k</h3>
                        <p>Assignments</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="stat-item">
                        <h3>26k</h3>
                        <p>Clients</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="stat-item">
                        <h3>72</h3>
                        <p>Countries</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="stat-item">
                        <h3>99.9%</h3>
                        <p>Satisfaction</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Partners Section -->
    <section class="partners-section">
        <div class="container">
            <h2 class="section-title text-center">Our Partner</h2>
            <div class="partner-logos">
                <!-- Partner logos will be added here -->
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <h2>Define specific, measurable goals for your students</h2>
                    <div class="feature-item">
                        <div class="feature-header">
                            <i class="fas fa-check-circle"></i>
                            <h4>No Fee to join</h4>
                        </div>
                        <p>Access our network of expert tutors, student projects, or schedule a consultation</p>
                    </div>
                    <div class="feature-item">
                        <div class="feature-header">
                            <i class="fas fa-users"></i>
                            <h4>Finding good client</h4>
                        </div>
                        <p>Connect with qualified students and educational institutions</p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <img src="assets/images/students.png" alt="Students" class="img-fluid">
                </div>
            </div>
        </div>
    </section>

    <!-- Subjects Section -->
    <section class="subjects-section">
        <div class="container">
            <h2 class="section-title text-center">Browse Subject By Category</h2>
            <div class="row">
                <!-- Subject categories will be dynamically added -->
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section bg-primary">
        <div class="container-fluid px-0">
            <div class="row g-0 align-items-center">
                <div class="col-lg-7">
                    <div class="cta-content">
                        <h2>The leading freelance solution for educational institutions.</h2>
                        <div class="cta-features">
                            <div class="row g-4">
                                <div class="col-md-6">
                                    <div class="feature">
                                        <h4>Dedicated hiring experts</h4>
                                        <p>Count on an account manager to find you the right talent and see to your project's every need.</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="feature">
                                        <h4>Satisfaction guarantee</h4>
                                        <p>Count on an account manager to find you the right talent and see to your project's every need.</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="feature">
                                        <h4>Advanced management</h4>
                                        <p>Count on an account manager to find you the right talent and see to your project's every need.</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="feature">
                                        <h4>Flexible payment models</h4>
                                        <p>Count on an account manager to find you the right talent and see to your project's every need.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 cta-image-wrapper">
                    <img src="assets/images/tutor.png" alt="Online tutor" class="img-fluid">
                </div>
            </div>
        </div>
    </section>

    <!-- Reviews Section -->
    <section class="reviews-section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">What Our Students Say</h2>
                <p class="section-subtitle">Real stories from our students who have experienced the quality of our education system and achieved their goals.</p>
            </div>
            
            <div class="reviews-slider">
                <div class="row">
                    <div class="col-lg-6 mb-4">
                        <div class="review-card">
                            <div class="review-header">
                                <div class="reviewer-info">
                                    <img src="assets/images/reviewers/guy-hawkins.png" alt="Guy Hawkins" class="reviewer-image">
                                    <div class="reviewer-details">
                                        <h5 class="reviewer-name">Guy Hawkins</h5>
                                        <span class="review-time">1 week ago</span>
                                    </div>
                                </div>
                                <div class="review-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                            </div>
                            <div class="review-content">
                                <p>I appreciate the precise short videos (10 mins or less each) because overly long videos tend to make me lose focus. The instructor is very knowledgeable in Web Design and it shows as he shares his knowledge. These were my best 6 months of training. Thanks, Vako.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-6 mb-4">
                        <div class="review-card">
                            <div class="review-header">
                                <div class="reviewer-info">
                                    <img src="assets/images/reviewers/bessie-cooper.png" alt="Bessie Cooper" class="reviewer-image">
                                    <div class="reviewer-details">
                                        <h5 class="reviewer-name">Bessie Cooper</h5>
                                        <span class="review-time">6 hours ago</span>
                                    </div>
                                </div>
                                <div class="review-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                            </div>
                            <div class="review-content">
                                <p>Webflow course was good, it covers design secrets, and to build responsive web pages, blog, and some more tricks and tips about webflow. I enjoyed the course and it helped me to add web development skills related to webflow in my toolbox. Thank you Vako.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Teacher Section -->
    <section class="teacher-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="teacher-grid">
                        <!-- Teacher profile images will be added here -->
                    </div>
                </div>
                <div class="col-lg-6">
                    <h2>Find The Best Teacher Here for your work</h2>
                    <p>Focus on what's really in their mind, whether it's foundational knowledge or advanced skills. Take our expert advice to address their individual needs.</p>
                    <button class="btn btn-primary">Find Best Teacher</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <?php include 'includes/footer.php'; ?>

    <!-- Auth Modals -->
    <?php 
    include 'includes/auth-modals.php';
    renderAuthModal('login');
    renderAuthModal('signup');
    ?>

    <!-- Bootstrap JS and other scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/login-modal.js"></script>
</body>
</html> 