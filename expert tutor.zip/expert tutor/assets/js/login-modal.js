document.addEventListener('DOMContentLoaded', function() {
    // User Type Toggle for both modals
    document.querySelectorAll('.user-type-toggle .btn').forEach(button => {
        button.addEventListener('click', function() {
            const toggle = this.closest('.user-type-toggle');
            toggle.querySelectorAll('.btn').forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Login Method Toggle for both modals
    document.querySelectorAll('.login-method-tabs .btn').forEach(button => {
        button.addEventListener('click', function() {
            const tabs = this.closest('.login-method-tabs');
            const form = this.closest('.login-form-panel').querySelector('form');
            const emailInput = form.querySelector('input[type="email"]');
            
            tabs.querySelectorAll('.btn').forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Switch input type based on selected method
            if (this.dataset.method === 'mobile') {
                emailInput.type = 'tel';
                emailInput.placeholder = 'Mobile Number';
            } else {
                emailInput.type = 'email';
                emailInput.placeholder = 'Email';
            }
        });
    });

    // Form Validation and Submission
    document.querySelectorAll('.auth-form').forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const isLogin = this.classList.contains('login-form');
            const formData = new FormData(this);
            console.log(`${isLogin ? 'Login' : 'Signup'} form submitted:`, Object.fromEntries(formData));
            
            // You would typically make an API call here
        });
    });

    // Social Login Handlers
    document.querySelectorAll('.btn-social').forEach(button => {
        button.addEventListener('click', function() {
            const platform = this.querySelector('i').classList[1].split('-')[1];
            const isLogin = this.closest('form').classList.contains('login-form');
            console.log(`Initiating ${platform} ${isLogin ? 'login' : 'signup'}`);
            // Add your social login/signup logic here
        });
    });

    // Input Focus Effects
    document.querySelectorAll('.input-group').forEach(group => {
        const input = group.querySelector('.form-control');
        input.addEventListener('focus', () => {
            group.style.borderColor = '#6C5CE7';
        });
        input.addEventListener('blur', () => {
            group.style.borderColor = '';
        });
    });

    // Modal Switch Handling
    const loginModal = document.getElementById('loginModal');
    const signupModal = document.getElementById('signupModal');

    // Handle modal switching
    document.querySelectorAll('[data-bs-toggle="modal"]').forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.classList.contains('signup-link') || this.classList.contains('login-link')) {
                e.preventDefault();
                const targetModalId = this.getAttribute('data-bs-target');
                const targetModal = new bootstrap.Modal(document.querySelector(targetModalId));
                
                // Hide current modal
                const currentModal = bootstrap.Modal.getInstance(document.querySelector('.modal.show'));
                if (currentModal) {
                    currentModal.hide();
                    // Wait for the first modal to finish hiding before showing the new one
                    document.querySelector('.modal.show').addEventListener('hidden.bs.modal', function handler() {
                        this.removeEventListener('hidden.bs.modal', handler);
                        targetModal.show();
                    });
                } else {
                    targetModal.show();
                }
            }
        });
    });

    // Initialize Bootstrap modals
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        new bootstrap.Modal(modal);
    });
}); 