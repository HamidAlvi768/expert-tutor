<footer class="main-footer bg-dark text-light py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
                <img src="assets/images/logo-white.png" alt="Assignment Connect" class="footer-logo mb-4">
                <p>Connecting educational institutions with expert tutors worldwide.</p>
                <div class="social-links">
                    <a href="#" class="me-3"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="me-3"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="me-3"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
                <h4>Top Categories</h4>
                <ul class="list-unstyled">
                    <li><a href="#">Mathematics</a></li>
                    <li><a href="#">Science</a></li>
                    <li><a href="#">Content Writing</a></li>
                    <li><a href="#">Commerce Stream</a></li>
                </ul>
            </div>
            
            <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
                <h4>Quick Links</h4>
                <ul class="list-unstyled">
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">How It Works</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                </ul>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <h4>Download Our App</h4>
                <div class="app-buttons">
                    <a href="#" class="d-block mb-2">
                        <img src="assets/images/app-store.png" alt="App Store" class="img-fluid">
                    </a>
                    <a href="#" class="d-block">
                        <img src="assets/images/google-play.png" alt="Google Play" class="img-fluid">
                    </a>
                </div>
            </div>
        </div>
        
        <div class="row mt-5">
            <div class="col-12">
                <div class="footer-bottom text-center">
                    <p class="mb-0">&copy; <?php echo date('Y'); ?> Assignment Connect. All rights reserved.</p>
                </div>
            </div>
        </div>
    </div>
</footer> 